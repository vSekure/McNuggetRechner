﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace Mc_Nugget_rechner
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txt_anzahl.Focus();
        }

        private void mn_beenden_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("Wollen Sie das Programm wirklich beenden?", "Programm beenden", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                Close();
            }
        }

        private void mn_info_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Xianira", "About", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void txt_anzahl_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = !char.IsDigit(e.Text, e.Text.Length - 1);
        }

        private void txt_anzahl_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (int.TryParse(txt_anzahl.Text, out int i))
            {
                if (string.IsNullOrWhiteSpace(txt_anzahl.Text))
                {
                    lbl_20.Content = "";
                    lbl_6.Content = "";
                    lbl_9.Content = "";
                    lbl_ifnuggetnumber.Content = "";
                    return;
                }

                bool isMcNuggetNumber = false;

                for (int twenties = 0; twenties <= i / 20; twenties++)
                {
                    for (int nines = 0; nines <= (i - 20 * twenties) / 9; nines++)
                    {
                        int remaining = i - 20 * twenties - 9 * nines;
                        if (remaining % 6 == 0)
                        {
                            int sixes = remaining / 6;
                            lbl_20.Content = "Es werden " + twenties + " 20er Boxen verwendet";
                            lbl_9.Content = "Es werden " + nines + " 9er Boxen verwendet"; ;
                            lbl_6.Content = "Es werden " + sixes + " 6er Boxen verwendet";
                            lbl_ifnuggetnumber.Content = "Die Zahl ist eine McNugget-Zahl";
                            isMcNuggetNumber = true;
                            return;  // Stop searching once a valid combination is found
                        }
                    }
                }

                if (!isMcNuggetNumber)
                {
                    lbl_20.Content = "";
                    lbl_9.Content = "";
                    lbl_6.Content = "";
                    lbl_ifnuggetnumber.Content = "Die Zahl ist keine McNugget-Zahl";
                }
            }
            else
            {
                lbl_20.Content = "";
                lbl_6.Content = "";
                lbl_9.Content = "";
                lbl_ifnuggetnumber.Content = "";
            }
        }
    }
}
